#pragma once
#include "platform.h"
#include <vector>

class Ball
{
public:
    Ball();
    void Update(const std::vector<Platform>& platforms, int keyLeft, int keyRight, int keyJump);
    void Draw() const;
    float GetX() const { return x; }
    float GetY() const { return y; }
    float GetRadius() const { return radius; }
    float GetVX() const { return vx; }
    float GetVY() const { return vy; }
    void SetVX(float newVx) { vx = newVx; }
    void SetVY(float newVy) { vy = newVy; }


private:
    float x, y;
    float vx = 0;  // <--- new horizontal velocity

    float vy;
    float speedX = 0;
    float radius;
    int jumpsDone = 0;
    const float moveAccel = 4.0f;    // Acceleration when moving
    const float maxHSpeed = 10.0f;    // Max horizontal speed
    const float friction = 0.1f;     // Slow down over time
    const int maxJumps = 2;
    const float gravity = 0.5f;
    const float jumpStrength = 10.0f;
    const float moveSpeed = 5.0f;
};
