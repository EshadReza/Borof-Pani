#include "ball.h"
#include <raylib.h>
#include <stdio.h>
#include<math.h>
#include<cmath>

Ball::Ball()
    : x(200), y(50), vy(0), speedX(0), radius(15), jumpsDone(0)
{}

void Ball::Update(const std::vector<Platform>& platforms, int keyLeft, int keyRight, int keyJump)
{
    float groundLevel = GetScreenHeight();
    bool onPlatform = false;

    if (IsKeyDown(keyLeft)) vx -= moveAccel;
    else if (IsKeyDown(keyRight)) vx += moveAccel;
    else {
        // Apply friction (slow down when no input)
        if (vx > 0) vx -= friction;
        if (vx < 0) vx += friction;
        if (fabs(vx) < friction) vx = 0;
    }

    // Clamp horizontal velocity
    if (vx > maxHSpeed) vx = maxHSpeed;
    if (vx < -maxHSpeed) vx = -maxHSpeed;

    // Apply velocity
    x += vx;
    // Check for side collisions and bounce
    for (const auto& platform : platforms) {
        Rectangle plat = platform.GetRect();

        float platTop = plat.y;
        float platBottom = plat.y + plat.height;
        float platLeft = plat.x;
        float platRight = plat.x + plat.width;

        float ballTop = y - radius;
        float ballBottom = y + radius;
        float ballLeft = x - radius;
        float ballRight = x + radius;

        bool withinVertical = ballBottom > platTop && ballTop < platBottom;

        if (withinVertical) {
            // Hit from left
            if (ballRight > platLeft && ballLeft < platLeft && vx > 0) {
                x = platLeft - radius;
                vx = -vx * 0.7f; // bounce with energy loss
            }

            // Hit from right
            else if (ballLeft < platRight && ballRight > platRight && vx < 0) {
                x = platRight + radius;
                vx = -vx * 0.7f;
            }
        }
    }
    
    // Gravity
    vy += gravity;
    y += vy;

    float ballTop = y - radius;
    float ballBottom = y + radius;
    float ballLeft = x - radius;
    float ballRight = x + radius;

    
    // Platform collision
    for (const auto& platform : platforms) {
        Rectangle platRect = platform.GetRect();

        float platTop = platRect.y;
        float platBottom = platRect.y + platRect.height;
        float platLeft = platRect.x;
        float platRight = platRect.x + platRect.width;

        bool withinPlatformX = (ballRight > platLeft) && (ballLeft < platRight);

        // Landing on platform
        bool fallingOntoPlatform = (ballBottom - vy <= platTop) && (ballBottom >= platTop);

        if (fallingOntoPlatform && withinPlatformX && vy >= 0) {
            y = platTop - radius;
            vy = 0;
            onPlatform = true;

            // Inherit horizontal speed
            speedX = platform.GetSpeedX();
            vx = speedX;
            jumpsDone = 0;
            break;
        }

        // Hitting the platform from below
        bool hittingUnderPlatform = (ballTop - vy >= platBottom) && (ballTop <= platBottom);

        if (hittingUnderPlatform && withinPlatformX && vy < 0) {
            y = platBottom + radius;
            vy = 0;
            break;
        }
    }

    // Ground collision (only if not on platform)
    if (!onPlatform && ballBottom > groundLevel) {
        y = groundLevel - radius;
        vy = 0;
        onPlatform = true;
        jumpsDone = 0;
        speedX = 0;
    }

    // Jumping (double jump logic)
    if (IsKeyPressed(keyJump) && jumpsDone < maxJumps){
        vy = -jumpStrength;
        jumpsDone++;
        speedX = 0;  // lose platform speed when in air
    }

    // Bounce off walls with 3x energy
    if (x - radius <= 0 && vx < 0) {
        x = radius;
        vx = -vx * 20.0f;  // Super bounce off left wall
    }

    if (x + radius >= GetScreenWidth() && vx > 0) {
        x = GetScreenWidth() - radius;
        vx = -vx * 20.0f;  // Super bounce off right wall
    }


    // Debug
    //printf("Ball pos: x=%.2f, y=%.2f, vy=%.2f, jumps=%d\n", x, y, vy, jumpsDone);
}

void Ball::Draw() const
{
    DrawCircle((int)x, (int)y, radius, { 242, 95, 92, 255 });  // change RED to any color if needed
}