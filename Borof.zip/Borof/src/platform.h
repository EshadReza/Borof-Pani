#pragma once
#include <raylib.h>

class Platform {
public:
    Platform(float x, float y, float width, float height, float speedX = 3.0f);
    float GetSpeedX() const { return speedX; }

    void Update();
    void Draw() const;
    Rectangle GetRect() const;

private:
    Rectangle rect;
    float speedX;
};
