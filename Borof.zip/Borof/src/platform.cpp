#include "platform.h"

Platform::Platform(float x, float y, float width, float height, float speedX)
    : speedX(speedX)
{
    rect.x = x;
    rect.y = y;
    rect.width = width;
    rect.height = height;
}

void Platform::Update() {
    rect.x += speedX;

    if (rect.x <= 0) {
        rect.x = 0;
        speedX *= -1;
    } else if (rect.x + rect.width >= GetScreenWidth()) {
        rect.x = GetScreenWidth() - rect.width;
        speedX *= -1;
    }
}

void Platform::Draw() const {
    DrawRectangleRounded(rect, 1.0f, 5, { 255, 224, 102, 255 });
}

Rectangle Platform::GetRect() const {
    return rect;
}
