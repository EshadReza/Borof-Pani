#include <vector>
#include <raylib.h>
#include "ball.h"
#include "platform.h"
#include <cmath>

int main() {
    const int screenWidth = 1600;
    const int screenHeight = 900;
    InitWindow(screenWidth, screenHeight, "Multiple Platforms");
    SetTargetFPS(60);

    Ball ball1;  // Arrow keys
    Ball ball2;  // WASD


    std::vector<Platform> platforms;
    // Create 20 platforms at different heights and speeds
    float verticalSpacing = 80;                 // more space between platforms
    float startY = 100;
    float maxPlatformY = GetScreenHeight() - 2 * 15 - 20; // 2×radius + platform height
    
    for (int i = 0; i < 10; ++i) {
        float x = 80 * i;  // wider spacing if needed
        float y = startY + i * verticalSpacing;
    
        if (y > maxPlatformY) y = maxPlatformY - (15 - i) * 10;  // push upper ones up gradually
    
        float width = (200 + GetRandomValue(0, 100)) * 2.0f;  // double the width
        float height = 20;
        float speed = 2.0f + (i % 5);
    
        platforms.emplace_back(x, y, width, height, speed);
    }
    


    while (!WindowShouldClose()) {
        for (auto& platform : platforms)
            platform.Update();
    
        ball1.Update(platforms, KEY_LEFT, KEY_RIGHT, KEY_UP);
        ball2.Update(platforms, KEY_A, KEY_D, KEY_W);
        
        float dx = ball1.GetX() - ball2.GetX();
        float dy = ball1.GetY() - ball2.GetY();
        float distance = sqrt(dx * dx + dy * dy);
        float combinedRadius = ball1.GetRadius() + ball2.GetRadius();

        if (distance <= combinedRadius) {
            // Bounce each other (swap horizontal velocity or reverse)
            float tempVx = ball1.GetVX();
            ball1.SetVX(-ball2.GetVX());
            ball2.SetVX(-tempVx);

            // Optional: vertical bounce too
            float tempVy = ball1.GetVY();
            ball1.SetVY(-ball2.GetVY());
            ball2.SetVY(-tempVy);

            // Add heavy visual effect
            DrawCircle((ball1.GetX() + ball2.GetX()) / 2,
                    (ball1.GetY() + ball2.GetY()) / 2,
                    50, RED);  // Shockwave effect
        }

    
        BeginDrawing();
            ClearBackground({ 102, 82, 0, 255 });
            for (const auto& platform : platforms)
                platform.Draw();
            ball1.Draw();
            ball2.Draw();
        EndDrawing();
    }
    
    CloseWindow();
    return 0;
}
